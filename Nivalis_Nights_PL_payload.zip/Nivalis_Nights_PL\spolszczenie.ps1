param(
  [ValidateSet('Install','Uninstall','Check')][string]$Action = 'Install',
  [string]$GameDir = '',
  [string]$SettingsPath = ''
)
$ErrorActionPreference = 'Stop'
$package = $PSScriptRoot
function Test-Game([string]$path) {
  return $path -and (Test-Path -LiteralPath (Join-Path $path 'Nivalis Nights.exe')) -and (Test-Path -LiteralPath (Join-Path $path 'Nivalis Nights_Data\sharedassets0.assets'))
}
if ($GameDir) {
  $GameDir = [IO.Path]::GetFullPath($GameDir.Trim('"'))
  if (-not (Test-Game $GameDir)) { throw 'Podana sciezka nie jest folderem gry.' }
} else {
  $candidates = @($package,(Split-Path $package -Parent),(Get-Location).Path,'I:\Gry\Nivalis Nights','C:\GOG Games\Nivalis Nights','C:\Program Files (x86)\Steam\steamapps\common\Nivalis Nights')
  foreach ($candidate in $candidates) { if (Test-Game $candidate) { $GameDir = $candidate; break } }
  while (-not (Test-Game $GameDir)) { $GameDir = (Read-Host 'Podaj folder zawierajacy Nivalis Nights.exe').Trim('"') }
  $GameDir = [IO.Path]::GetFullPath($GameDir)
}
if (Get-Process -Name 'Nivalis Nights' -ErrorAction SilentlyContinue) { throw 'Zamknij gre przed instalacja lub odinstalowaniem.' }
$data = Join-Path $GameDir 'Nivalis Nights_Data'
$stateDir = Join-Path $GameDir '.nivalis_pl'
$original = Join-Path $stateDir 'original'
$stage = Join-Path $stateDir 'stage'
$statePath = Join-Path $stateDir 'state.json'
$manifest = Get-Content -LiteralPath (Join-Path $package 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$names = @('sharedassets0.assets','resources.assets')
$settings = if ($SettingsPath) { [IO.Path]::GetFullPath($SettingsPath) } else { Join-Path $env:USERPROFILE 'AppData\LocalLow\ION LANDS\Nivalis Nights\settings.ini' }
$state = $null
if (Test-Path -LiteralPath $statePath) { $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json }
function Hash-File([string]$path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
function Save-State($value) { $value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $statePath -Encoding UTF8 }
function Set-Language([string]$value) {
  $lines = @()
  if (Test-Path -LiteralPath $settings) { $lines = [IO.File]::ReadAllLines($settings) }
  $updated = [Collections.Generic.List[string]]::new()
  foreach ($line in $lines) { if ($line -notmatch '^\s*Language\s*=') { $updated.Add($line) } }
  if ($value) { $updated.Insert(0,$value) }
  New-Item -ItemType Directory -Path (Split-Path $settings -Parent) -Force | Out-Null
  [IO.File]::WriteAllLines($settings,$updated,[Text.UTF8Encoding]::new($false))
}
function Assert-Current($record) {
  foreach ($name in $names) {
    $actual = Hash-File (Join-Path $data $name)
    if ($actual -ne $record.installed_hashes.$name -and $actual -ne $record.original_hashes.$name) {
      throw "Plik $name zmienil sie po instalacji (np. aktualizacja gry). Przerwano, aby nie przywrocic starej wersji."
    }
  }
}
if ($Action -eq 'Uninstall') {
  if ($null -eq $state -or $state.status -eq 'uninstalled') { Write-Host 'Brak aktywnej instalacji tej paczki.'; exit 0 }
  Assert-Current $state
  foreach ($name in $names) {
    if ((Hash-File (Join-Path $original $name)) -ne $state.original_hashes.$name) { throw "Uszkodzona kopia oryginalu: $name" }
  }
  foreach ($name in $names) { Copy-Item -LiteralPath (Join-Path $original $name) -Destination (Join-Path $data $name) -Force }
  $language = @()
  if (Test-Path -LiteralPath $settings) { $language = @([IO.File]::ReadAllLines($settings) | Where-Object { $_ -match '^\s*Language\s*=' }) }
  if ($language -contains 'Language = French') { Set-Language $state.restore_language }
  $state.status = 'uninstalled'; Save-State $state
  Write-Host 'Spolszczenie odinstalowane. Przywrocono oryginalne pliki gry.'
  exit 0
}
Add-Type -Path (Join-Path $package 'tools\AssetsTools.NET.dll')
function Assert-Baseline([string]$path,[string]$file) {
  $m = [AssetsTools.NET.Extra.AssetsManager]::new()
  try {
    $m.LoadClassPackage((Join-Path $package 'tools\classdata.tpk')) | Out-Null
    $inst = $m.LoadAssetsFile($path,$true)
    $m.LoadClassDatabaseFromPackage($inst.file.Metadata.UnityVersion) | Out-Null
    $found = @{}
    foreach ($info in $inst.file.AssetInfos) {
      if ($info.TypeId -ne 49) { continue }
      $field = $m.GetBaseField($inst,$info,[AssetsTools.NET.Extra.AssetReadFlags]::ForceFromCldb)
      $name = $field.Get('m_Name').AsString
      $expected = $manifest.baseline_text_hashes.$name
      if ($expected) {
        if ($found.ContainsKey($name)) { throw "Powtorzona nazwa TextAsset: $name" }
        $sha = [Security.Cryptography.SHA256]::Create()
        try { $bytes = [Text.Encoding]::UTF8.GetBytes($field.Get('m_Script').AsString.TrimStart([char]0xfeff)); $hash = ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','') } finally { $sha.Dispose() }
        if ($hash -ne $expected) { throw "Teksty $name nie odpowiadaja obslugiwanej aktualizacji. Wymagana nowa paczka tlumaczenia lub czyste pliki gry." }
        $found[$name] = $true
      }
    }
    $required = if ($file -eq 'sharedassets0.assets') { @('LocFile_En') } else { @('LocCharacter','LocItem') }
    foreach ($name in $required) { if (-not $found.ContainsKey($name)) { throw "Brak zasobu $name w $path" } }
  } finally { $m.UnloadAll($true) | Out-Null }
}
$sources = @{}
if ($state) { Assert-Current $state }
if ($state) {
  foreach ($name in $names) {
    if ((Hash-File (Join-Path $original $name)) -ne $state.original_hashes.$name) { throw "Uszkodzona kopia oryginalu: $name" }
  }
}
foreach ($name in $names) {
  $source = Join-Path $original $name
  $checked = $false
  if (-not (Test-Path -LiteralPath $source)) {
    $legacy = Join-Path $data ($name + '.bak_pl_original')
    $source = Join-Path $data $name
    try { Assert-Baseline $source $name; $checked = $true } catch {
      if (-not (Test-Path -LiteralPath $legacy)) { throw }
      if ((Hash-File $source) -ne $manifest.migration_hashes.$name) {
        throw "Plik $name nie odpowiada rozpoznanej poprzedniej instalacji PL. Nie uzyto potencjalnie nieaktualnej kopii .bak_pl_original."
      }
      $source = $legacy
    }
  }
  if (-not $checked) { Assert-Baseline $source $name }
  $sources[$name] = $source
}
foreach ($entry in $manifest.translation_hashes.PSObject.Properties) {
  if ((Hash-File (Join-Path $package ('localization\'+$entry.Name))) -ne $entry.Value) { throw "Uszkodzony plik tlumaczenia: $($entry.Name)" }
}
if ($Action -eq 'Check') { Write-Host 'Zgodnosc oryginalow i integralnosc tlumaczenia: OK.'; exit 0 }
New-Item -ItemType Directory -Path $original,$stage -Force | Out-Null
foreach ($name in $names) { $target = Join-Path $original $name; if ($sources[$name] -ne $target) { Copy-Item -LiteralPath $sources[$name] -Destination $target -Force } }
& (Join-Path $package 'engine.ps1') -GameDir $GameDir -SourceDataDir $original -StagingDir $stage -PrepareOnly -UpdateSettings:$false
$originalHashes = @{}; $installedHashes = @{}
foreach ($name in $names) { $originalHashes[$name] = Hash-File (Join-Path $original $name); $installedHashes[$name] = Hash-File (Join-Path $stage ($name+'.pltmp')) }
$restoreLanguage = if ($state) { $state.restore_language } else { 'Language = English' }
if (-not $state) {
  $languageSource = if (Test-Path -LiteralPath "$settings.bak_pl") { "$settings.bak_pl" } else { $settings }
  if (Test-Path -LiteralPath $languageSource) { $line = @([IO.File]::ReadAllLines($languageSource) | Where-Object { $_ -match '^\s*Language\s*=' }); if ($line.Count) { $restoreLanguage = $line[0] } }
}
$newState = [pscustomobject]@{status='prepared';release=$manifest.release;original_hashes=$originalHashes;installed_hashes=$installedHashes;restore_language=$restoreLanguage}
Save-State $newState
try {
  foreach ($name in $names) { Copy-Item -LiteralPath (Join-Path $stage ($name+'.pltmp')) -Destination (Join-Path $data $name) -Force }
  Set-Language 'Language = French'
  $newState.status = 'installed'; Save-State $newState
} catch {
  foreach ($name in $names) { Copy-Item -LiteralPath (Join-Path $original $name) -Destination (Join-Path $data $name) -Force }
  Set-Language $restoreLanguage
  $newState.status = 'rolled_back'; Save-State $newState
  throw
}
Write-Host 'Spolszczenie zainstalowane. Polski tekst jest w slocie French/Francais.'
foreach ($name in $names) { Remove-Item -LiteralPath (Join-Path $stage ($name+'.pltmp')) -Force }
