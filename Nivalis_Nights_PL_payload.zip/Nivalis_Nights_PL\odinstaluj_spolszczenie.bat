@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0spolszczenie.ps1" -Action Uninstall
if errorlevel 1 echo Odinstalowanie nie powiodlo sie. Przeczytaj komunikat powyzej.
pause
