param(
  [string]$GameDir = '',
  [bool]$UpdateSettings = $true,
  [switch]$NoBackup,
  [string]$SourceDataDir = '',
  [string]$StagingDir = '',
  [switch]$PrepareOnly
)

$ErrorActionPreference = 'Stop'

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$tools = Join-Path $packageRoot 'tools'
$loc = Join-Path $packageRoot 'localization'

function Test-GameDir([string]$candidate) {
  if ([string]::IsNullOrWhiteSpace($candidate)) { return $false }
  try {
    $full = [System.IO.Path]::GetFullPath($candidate.Trim('"'))
  } catch {
    return $false
  }
  return (
    (Test-Path -LiteralPath (Join-Path $full 'Nivalis Nights.exe') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $full 'Nivalis Nights_Data\sharedassets0.assets') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $full 'Nivalis Nights_Data\resources.assets') -PathType Leaf)
  )
}

function Add-Candidate([System.Collections.Generic.List[string]]$list, [string]$candidate) {
  if ([string]::IsNullOrWhiteSpace($candidate)) { return }
  try {
    $full = [System.IO.Path]::GetFullPath(($candidate.Trim('"')))
  } catch {
    return
  }
  foreach ($existing in $list) {
    if ([string]::Equals($existing, $full, [System.StringComparison]::OrdinalIgnoreCase)) { return }
  }
  $list.Add($full) | Out-Null
}

function Get-SteamLibraryPaths {
  $paths = New-Object System.Collections.Generic.List[string]
  $steamRoots = @()
  $registryKeys = @(
    'HKCU:\Software\Valve\Steam',
    'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam',
    'HKLM:\SOFTWARE\Valve\Steam'
  )
  foreach ($key in $registryKeys) {
    try {
      $props = Get-ItemProperty -LiteralPath $key -ErrorAction Stop
      if ($props.SteamPath) { $steamRoots += $props.SteamPath }
      if ($props.InstallPath) { $steamRoots += $props.InstallPath }
    } catch {}
  }
  $steamRoots += 'C:\Program Files (x86)\Steam'
  $steamRoots += 'C:\Program Files\Steam'

  foreach ($root in $steamRoots) {
    if ([string]::IsNullOrWhiteSpace($root)) { continue }
    $libraryFile = Join-Path $root 'steamapps\libraryfolders.vdf'
    Add-Candidate $paths $root
    if (Test-Path -LiteralPath $libraryFile -PathType Leaf) {
      $content = Get-Content -LiteralPath $libraryFile -Raw -ErrorAction SilentlyContinue
      foreach ($match in [regex]::Matches($content, '"path"\s+"([^"]+)"')) {
        Add-Candidate $paths ($match.Groups[1].Value -replace '\\\\', '\')
      }
    }
  }

  return $paths
}

function Find-NivalisGameDir {
  $candidates = New-Object System.Collections.Generic.List[string]
  Add-Candidate $candidates $packageRoot
  Add-Candidate $candidates (Split-Path -Parent $packageRoot)
  Add-Candidate $candidates (Get-Location).Path
  Add-Candidate $candidates (Join-Path (Get-Location).Path 'Nivalis Nights')
  Add-Candidate $candidates 'C:\GOG Games\Nivalis Nights'
  Add-Candidate $candidates 'C:\Program Files\GOG Galaxy\Games\Nivalis Nights'
  Add-Candidate $candidates 'C:\Program Files\Epic Games\Nivalis Nights'
  Add-Candidate $candidates 'C:\Program Files (x86)\Steam\steamapps\common\Nivalis Nights'
  Add-Candidate $candidates 'C:\Program Files\Steam\steamapps\common\Nivalis Nights'

  foreach ($steamLibrary in Get-SteamLibraryPaths) {
    Add-Candidate $candidates (Join-Path $steamLibrary 'steamapps\common\Nivalis Nights')
  }

  $uninstallRoots = @(
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
  )
  foreach ($root in $uninstallRoots) {
    try {
      Get-ItemProperty -Path $root -ErrorAction Stop |
        Where-Object { $_.DisplayName -like '*Nivalis Nights*' -and $_.InstallLocation } |
        ForEach-Object { Add-Candidate $candidates $_.InstallLocation }
    } catch {}
  }

  $epicManifestDir = 'C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests'
  if (Test-Path -LiteralPath $epicManifestDir -PathType Container) {
    Get-ChildItem -LiteralPath $epicManifestDir -Filter '*.item' -File -ErrorAction SilentlyContinue | ForEach-Object {
      try {
        $manifest = Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json
        if (($manifest.DisplayName -like '*Nivalis Nights*' -or $manifest.AppName -like '*Nivalis*') -and $manifest.InstallLocation) {
          Add-Candidate $candidates $manifest.InstallLocation
        }
      } catch {}
    }
  }

  foreach ($candidate in $candidates) {
    if (Test-GameDir $candidate) { return [System.IO.Path]::GetFullPath($candidate) }
  }

  return $null
}

function Resolve-GameDir([string]$requestedPath) {
  if (Test-GameDir $requestedPath) {
    return [System.IO.Path]::GetFullPath($requestedPath.Trim('"'))
  }
  if (-not [string]::IsNullOrWhiteSpace($requestedPath)) {
    Write-Host "Podana sciezka nie wyglada na folder gry: $requestedPath"
  }

  $detected = Find-NivalisGameDir
  if ($detected) {
    Write-Host "Wykryto folder gry: $detected"
    return $detected
  }

  while ($true) {
    $entered = Read-Host 'Nie wykryto gry automatycznie. Podaj pelna sciezke do folderu z plikiem "Nivalis Nights.exe"'
    if (Test-GameDir $entered) {
      return [System.IO.Path]::GetFullPath($entered.Trim('"'))
    }
    Write-Host 'To nie jest poprawny folder gry. Przyklad: D:\SteamLibrary\steamapps\common\Nivalis Nights'
  }
}

$GameDir = Resolve-GameDir $GameDir
$dataDir = Join-Path $GameDir 'Nivalis Nights_Data'

$inputDir = if ($SourceDataDir) { $SourceDataDir } else { $dataDir }
$sharedAssets = Join-Path $inputDir 'sharedassets0.assets'
$resourcesAssets = Join-Path $inputDir 'resources.assets'
$locFile = Join-Path $loc 'LocFile_pl.txt'
$locCharacter = Join-Path $loc 'LocCharacter_pl.txt'
$locItem = Join-Path $loc 'LocItem_pl.txt'

function Assert-File([string]$path) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "Missing file: $path"
  }
}

function Assert-InDataDir([string]$path) {
  $resolvedPath = [System.IO.Path]::GetFullPath($path)
  $resolvedRoot = [System.IO.Path]::GetFullPath($dataDir)
  if (-not $resolvedRoot.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
    $resolvedRoot += [System.IO.Path]::DirectorySeparatorChar
  }
  if (-not $resolvedPath.StartsWith($resolvedRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to write outside game data directory: $resolvedPath"
  }
}

function Get-ChildField($field, [string]$name) {
  foreach ($child in $field.Children) {
    if ($child.FieldName -eq $name) { return ,$child }
  }
  throw "Field not found: $name"
}

function Write-AlignedString([System.IO.BinaryWriter]$writer, [string]$text) {
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
  $writer.Write([int]$bytes.Length)
  $writer.Write($bytes)
  while (($writer.BaseStream.Position % 4) -ne 0) {
    $writer.Write([byte]0)
  }
}

function New-TextAssetBytes([string]$name, [string]$script) {
  $memory = [System.IO.MemoryStream]::new()
  $writer = [System.IO.BinaryWriter]::new($memory, [System.Text.UTF8Encoding]::new($false), $true)
  try {
    Write-AlignedString $writer $name
    Write-AlignedString $writer $script
    $writer.Flush()
    return ,$memory.ToArray()
  } finally {
    $writer.Dispose()
    $memory.Dispose()
  }
}

function Read-AssetBytes([string]$path, [long]$offset, [long]$size) {
  if ($size -gt [int]::MaxValue) { throw "Asset too large to compare in memory: $size bytes" }
  $bytes = New-Object byte[] ([int]$size)
  $stream = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
  try {
    $stream.Position = $offset
    $read = $stream.Read($bytes, 0, $bytes.Length)
    if ($read -ne $bytes.Length) { throw "Could not read full asset payload from $path" }
    return ,$bytes
  } finally {
    $stream.Dispose()
  }
}

function Test-ByteArrayEqual([byte[]]$left, [byte[]]$right) {
  if ($left.Length -ne $right.Length) { return $false }
  for ($i = 0; $i -lt $left.Length; $i++) {
    if ($left[$i] -ne $right[$i]) { return $false }
  }
  return $true
}

function Patch-AssetsFile([string]$inputPath, [string]$outputPath, [hashtable]$updates) {
  $manager = [AssetsTools.NET.Extra.AssetsManager]::new()
  $manager.LoadClassPackage((Join-Path $tools 'classdata.tpk')) | Out-Null
  $inst = $manager.LoadAssetsFile($inputPath, $true)
  $manager.LoadClassDatabaseFromPackage($inst.file.Metadata.UnityVersion) | Out-Null
  $flags = [AssetsTools.NET.Extra.AssetReadFlags]::ForceFromCldb
  $patched = @()

  foreach ($assetName in $updates.Keys) {
    $assetMatches = @()
    foreach ($candidate in $inst.file.AssetInfos) {
      if ($candidate.TypeId -ne 49) { continue }
      $candidateField = $manager.GetBaseField($inst, $candidate, $flags)
      if ((Get-ChildField $candidateField 'm_Name').AsString -ceq $assetName) {
        $assetMatches += [pscustomobject]@{ info = $candidate; field = $candidateField }
      }
    }
    if ($assetMatches.Count -ne 1) {
      throw "Expected one TextAsset named '$assetName' in $inputPath, found $($assetMatches.Count)"
    }
    $info = $assetMatches[0].info
    $field = $assetMatches[0].field
    $pathId = [int64]$info.PathId
    $textPath = $updates[$assetName]
    Assert-File $textPath
    $newText = [System.IO.File]::ReadAllText($textPath, [System.Text.UTF8Encoding]::new($true))
    $nameField = Get-ChildField $field 'm_Name'
    $scriptField = Get-ChildField $field 'm_Script'
    $assetName = $nameField.AsString
    $oldScript = $scriptField.AsString

    $originalBytes = Read-AssetBytes $inputPath ($info.GetAbsoluteByteOffset($inst.file)) $info.ByteSize
    $roundTripBytes = New-TextAssetBytes $assetName $oldScript
    if (-not (Test-ByteArrayEqual -left ([byte[]]$originalBytes) -right ([byte[]]$roundTripBytes))) {
      throw "TextAsset serialization check failed for path_id $pathId in $inputPath"
    }

    $newBytes = New-TextAssetBytes $assetName $newText
    $info.SetNewData([byte[]]$newBytes)
    $patched += [pscustomobject]@{
      file = Split-Path -Leaf $inputPath
      path_id = $pathId
      name = $assetName
      old_chars = $oldScript.Length
      new_chars = $newText.Length
      old_bytes = $originalBytes.Length
      new_bytes = $newBytes.Length
    }
  }

  $outDir = Split-Path -Parent $outputPath
  New-Item -ItemType Directory -Force -Path $outDir | Out-Null
  if (Test-Path -LiteralPath $outputPath) { Remove-Item -Force -LiteralPath $outputPath }
  $writer = [AssetsTools.NET.AssetsFileWriter]::new($outputPath)
  try {
    $inst.file.Write($writer, 0)
  } finally {
    $writer.BaseStream.Close()
    $manager.UnloadAll($true) | Out-Null
  }

  return $patched
}

function Install-PatchedFile([string]$sourcePath, [string]$patchedPath) {
  Assert-InDataDir $sourcePath
  Assert-InDataDir $patchedPath
  Assert-File $patchedPath

  $backupPath = "$sourcePath.bak_pl_original"
  if (-not $NoBackup -and -not (Test-Path -LiteralPath $backupPath)) {
    Copy-Item -LiteralPath $sourcePath -Destination $backupPath -Force
    Write-Host "Backup: $backupPath"
  }

  Copy-Item -LiteralPath $patchedPath -Destination $sourcePath -Force
  Remove-Item -LiteralPath $patchedPath -Force
  Write-Host "Installed: $sourcePath"
}

function Set-FrenchSlotLanguage {
  $settingsDir = Join-Path $env:USERPROFILE 'AppData\LocalLow\ION LANDS\Nivalis Nights'
  $settingsPath = Join-Path $settingsDir 'settings.ini'
  New-Item -ItemType Directory -Force -Path $settingsDir | Out-Null

  if ((Test-Path -LiteralPath $settingsPath) -and -not (Test-Path -LiteralPath "$settingsPath.bak_pl")) {
    Copy-Item -LiteralPath $settingsPath -Destination "$settingsPath.bak_pl" -Force
    Write-Host "Settings backup: $settingsPath.bak_pl"
  }

  $lines = @()
  if (Test-Path -LiteralPath $settingsPath) {
    $lines = [System.IO.File]::ReadAllLines($settingsPath)
  }

  $updated = [System.Collections.Generic.List[string]]::new()
  $found = $false
  foreach ($line in $lines) {
    if ($line -match '^\s*Language\s*=') {
      $updated.Add('Language = French')
      $found = $true
    } else {
      $updated.Add($line)
    }
  }
  if (-not $found) {
    $updated.Insert(0, 'Language = French')
  }

  [System.IO.File]::WriteAllLines($settingsPath, $updated, [System.Text.UTF8Encoding]::new($false))
  Write-Host "Set runtime language slot: French"
}

Assert-File (Join-Path $tools 'AssetsTools.NET.dll')
Assert-File (Join-Path $tools 'AssetsTools.NET.Cpp2IL.dll')
Assert-File (Join-Path $tools 'AssetsTools.NET.MonoCecil.dll')
Assert-File (Join-Path $tools 'classdata.tpk')
Assert-File $sharedAssets
Assert-File $resourcesAssets
Assert-File $locFile
Assert-File $locCharacter
Assert-File $locItem

Add-Type -Path (Join-Path $tools 'AssetsTools.NET.dll')
Add-Type -Path (Join-Path $tools 'AssetsTools.NET.Cpp2IL.dll')
Add-Type -Path (Join-Path $tools 'AssetsTools.NET.MonoCecil.dll')

$outputDir = if ($StagingDir) { $StagingDir } else { $dataDir }
$tempShared = Join-Path $outputDir 'sharedassets0.assets.pltmp'
$tempResources = Join-Path $outputDir 'resources.assets.pltmp'

Write-Host "Patching sharedassets0.assets..."
$summary = @()
$summary += Patch-AssetsFile $sharedAssets $tempShared @{
  'LocFile_En' = $locFile
  'LocFile_fre' = $locFile
}

Write-Host "Patching resources.assets..."
$summary += Patch-AssetsFile $resourcesAssets $tempResources @{
  'LocCharacter' = $locCharacter
  'LocItem' = $locItem
}

if ($PrepareOnly) {
  $summary | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $outputDir 'patch_report.json') -Encoding UTF8
  return
}
Install-PatchedFile $sharedAssets $tempShared
Install-PatchedFile $resourcesAssets $tempResources

if ($UpdateSettings) {
  Set-FrenchSlotLanguage
}

$reportPath = Join-Path $packageRoot 'install_report.json'
$summary | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 -Path $reportPath

Write-Host ""
Write-Host "Done. Polish localization is installed in the French/Francais language slot."
Write-Host "Report: $reportPath"
