@echo off
setlocal
cd /d "%~dp0"
echo Nivalis Nights - spolszczenie
echo [1] Zainstaluj spolszczenie
echo [2] Odinstaluj spolszczenie
echo [Q] Zamknij
choice /C 12Q /N /M "Wybierz: "
if errorlevel 3 exit /b
if errorlevel 2 (
  call "%~dp0odinstaluj_spolszczenie.bat"
) else (
  call "%~dp0zainstaluj_spolszczenie.bat"
)
