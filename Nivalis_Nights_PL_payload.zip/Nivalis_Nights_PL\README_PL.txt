NIVALIS NIGHTS - SPOLSZCZENIE PO KOREKCIE ONLINE, 2026-10-06

INSTALACJA
Rozpakuj cala paczke ZIP. Zamknij gre i uruchom zainstaluj_spolszczenie.bat.
Instalator wykrywa folder gry lub prosi o jego wskazanie. Tekst polski dziala w slocie French/Francais.
Mozesz tez skopiowac folder paczki do katalogu gry i uruchomic instalacje stamtad.

ODINSTALOWANIE
Zamknij gre i uruchom odinstaluj_spolszczenie.bat. Przywraca oryginalne pliki i poprzedni jezyk, zachowujac pozostale ustawienia.
Kopie sa w folderze .nivalis_pl w katalogu gry. Zachowaj je do odinstalowania.
Po odinstalowaniu kopie pozostaja na dysku, aby mozna bylo ponownie zainstalowac paczke.
Pliki .bak_pl_original poprzedniego patchera tez pozostaja; instalator moze wykorzystac je przy migracji, jesli odpowiadaja obslugiwanej wersji.

WERSJA GRY
Paczka jest przygotowana na katalogach lokalizacji aktualizacji z 2/3 pazdziernika 2026.
Sprawdza oryginalne teksty i sumy kontrolne. Przy niezgodnej aktualizacji lub uszkodzonych kopiach zatrzymuje sie z komunikatem.
Odinstalowanie nie przywraca starych plikow nad rozpoznana zmiana gry po instalacji. Wtedy przywroc czyste pliki przez mechanizm naprawy instalacji gry i uzyj paczki dla odpowiedniej wersji.

ZAWARTOSC
106793 wpisy w aktualnych katalogach lokalizacji, 18224 poprawki z zatwierdzonego zestawu zbiorczego.
Paczka zawiera tylko teksty i narzedzia. Duze archiwa Unity sa budowane lokalnie.
Potrzeba okolo 5 GB wolnego miejsca podczas instalacji na kopie i pliki robocze, dodatkowo do istniejacych kopii starego patchera. Po instalacji pozostaja kopie oryginalow (okolo 1.5 GB).

LINIA POLECEN
powershell -NoProfile -ExecutionPolicy Bypass -File .\spolszczenie.ps1 -Action Install -GameDir "D:\Gry\Nivalis Nights"
powershell -NoProfile -ExecutionPolicy Bypass -File .\spolszczenie.ps1 -Action Uninstall -GameDir "D:\Gry\Nivalis Nights"
powershell -NoProfile -ExecutionPolicy Bypass -File .\spolszczenie.ps1 -Action Check -GameDir "D:\Gry\Nivalis Nights"
