@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0spolszczenie.ps1" -Action Install
if errorlevel 1 echo Instalacja nie powiodla sie. Przeczytaj komunikat powyzej.
pause
